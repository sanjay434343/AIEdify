import React from 'react';
import CodeMirror from '@uiw/react-codemirror';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { javascript } from '@codemirror/lang-javascript';

interface CodeEditorProps {
  activeTab: string;
  htmlCode: string;
  cssCode: string;
  jsCode: string;
  onHtmlChange: (value: string) => void;
  onCssChange: (value: string) => void;
  onJsChange: (value: string) => void;
  onTabChange: (tab: string) => void;
}

export function CodeEditor({
  activeTab,
  htmlCode,
  cssCode,
  jsCode,
  onHtmlChange,
  onCssChange,
  onJsChange,
  onTabChange,
}: CodeEditorProps) {
  const tabs = [
    { id: 'html', label: 'HTML' },
    { id: 'css', label: 'CSS' },
    { id: 'js', label: 'JavaScript' },
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="border-b border-gray-200 px-4 py-2">
        <div className="flex space-x-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`px-4 py-2 rounded-md transition-colors duration-200 ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="h-[500px] overflow-auto p-4">
        {activeTab === 'html' && (
          <CodeMirror
            value={htmlCode}
            height="100%"
            theme="light"
            extensions={[html()]}
            onChange={onHtmlChange}
            className="text-sm"
          />
        )}
        {activeTab === 'css' && (
          <CodeMirror
            value={cssCode}
            height="100%"
            theme="light"
            extensions={[css()]}
            onChange={onCssChange}
            className="text-sm"
          />
        )}
        {activeTab === 'js' && (
          <CodeMirror
            value={jsCode}
            height="100%"
            theme="light"
            extensions={[javascript()]}
            onChange={onJsChange}
            className="text-sm"
          />
        )}
      </div>
    </div>
  );
}