import React from 'react';

interface PreviewProps {
  output: string;
}

export function Preview({ output }: PreviewProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="border-b border-gray-200 px-4 py-2">
        <h2 className="text-lg font-semibold text-gray-900">Preview</h2>
      </div>
      <div className="h-[500px] bg-white p-4">
        <iframe
          srcDoc={output}
          title="output"
          className="w-full h-full rounded border border-gray-200"
          sandbox="allow-scripts"
        />
      </div>
    </div>
  );
}